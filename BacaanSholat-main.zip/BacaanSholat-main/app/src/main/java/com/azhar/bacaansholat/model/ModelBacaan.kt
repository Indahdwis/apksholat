package com.azhar.bacaansholat.model

/**
 * Created by Azhar Rivaldi on 31-01-2021
 */

class ModelBacaan {
    var id: String? = null
    var name: String? = null
    var arabic: String? = null
    var latin: String? = null
    var terjemahan: String? = null
}